# Фундаментальные утилиты RL системы обучения агентов

Этот документ описывает 5 ключевых модулей утилит, созданных для системы обучения агентов подкрепляющего обучения.

## 📁 Структура модулей

```
src/
├── utils/
│   ├── __init__.py           # Экспорт основных компонентов
│   ├── seeding.py           # T010 - Воспроизводимость (уже существовал)
│   ├── logging.py           # T011 - Структурированное логирование
│   ├── checkpointing.py     # T012 - Управление чекпоинтами
│   ├── config.py            # T013 - Управление конфигурацией
│   └── metrics.py           # T014 - Отслеживание метрик
└── experiments/
    ├── __init__.py
    └── base.py              # T015 - Базовый класс экспериментов
```

## 🛠️ Описание модулей

### 1. src/utils/logging.py (T011)

**Назначение**: Структурированное логирование с интеграцией в Stable-Baselines3

**Ключевые возможности**:
- ✅ JSON-структурированные логи для экспериментов
- ✅ Интеграция с Stable-Baselines3 callbacks
- ✅ Файловое и консольное логирование
- ✅ Ротация логов и автоочистка
- ✅ Различные уровни логирования для компонентов
- ✅ Контекстные логгеры для экспериментов

**Основные классы**:
- `JSONFormatter` - форматирование в JSON
- `ExperimentLoggerAdapter` - логгер с контекстом эксперимента
- `TrainingCallback` - интеграция с SB3
- `MetricsLogger` - специализированный логгер метрик

**Пример использования**:
```python
from src.utils.logging import setup_logging, get_experiment_logger

# Настройка логирования
logger = setup_logging(log_level="INFO", json_format=True)

# Логгер для эксперимента
exp_logger = get_experiment_logger("my_experiment")
exp_logger.log_training_step(timestep=100, episode=5, reward=15.5)
```

### 2. src/utils/checkpointing.py (T012)

**Назначение**: Управление чекпоинтами и восстановление состояния обучения

**Ключевые возможности**:
- ✅ Сохранение/загрузка чекпоинтов с метаданными
- ✅ Автоматическое управление количеством чекпоинтов
- ✅ Валидация целостности чекпоинтов
- ✅ Поддержка восстановления состояния эксперимента
- ✅ Сохранение лучших N чекпоинтов
- ✅ Хеширование файлов для проверки целостности

**Основные классы**:
- `CheckpointMetadata` - метаданные чекпоинта
- `CheckpointManager` - управление чекпоинтами

**Пример использования**:
```python
from src.utils.checkpointing import CheckpointManager, create_checkpoint_metadata

# Создание менеджера
manager = CheckpointManager("checkpoints", "experiment_1", max_checkpoints=5)

# Создание метаданных
metadata = create_checkpoint_metadata(
    experiment_id="experiment_1",
    timestep=1000,
    episode=50,
    reward=25.5,
    model_class="PPO",
    algorithm="PPO",
    environment="LunarLander-v3",
    seed=42,
    hyperparameters={"learning_rate": 3e-4}
)

# Сохранение чекпоинта
checkpoint_path = manager.save_checkpoint(model, metadata)
```

### 3. src/utils/config.py (T013)

**Назначение**: Управление конфигурацией с интеграцией Hydra

**Ключевые возможности**:
- ✅ Интеграция с Hydra для загрузки конфигураций
- ✅ Валидация параметров конфигурации
- ✅ Подстановка переменных окружения
- ✅ Слияние и переопределение конфигураций
- ✅ Типобезопасный доступ к настройкам
- ✅ Поддержка конфигураций по умолчанию

**Основные классы**:
- `RLConfig` - основная конфигурация системы
- `AlgorithmConfig` - конфигурация алгоритма
- `EnvironmentConfig` - конфигурация среды
- `TrainingConfig` - конфигурация обучения
- `ConfigLoader` - загрузчик конфигураций

**Пример использования**:
```python
from src.utils.config import RLConfig, ConfigLoader, load_config

# Создание конфигурации по умолчанию
config = RLConfig()

# Загрузка из файла
config = load_config("ppo_lunarlander")

# Загрузка с переопределениями
config = load_config("default", overrides=["algorithm.learning_rate=1e-3"])
```

### 4. src/utils/metrics.py (T014)

**Назначение**: Отслеживание и анализ метрик обучения

**Ключевые возможности**:
- ✅ Сбор метрик в реальном времени
- ✅ Интеграция с Stable-Baselines3 callbacks
- ✅ Агрегация и статистический анализ
- ✅ Экспорт в JSON/CSV форматы
- ✅ Построение графиков метрик
- ✅ Поддержка пользовательских метрик
- ✅ Анализ сходимости обучения

**Основные классы**:
- `MetricPoint` - точка метрики с временной меткой
- `MetricSummary` - сводная статистика
- `MetricsTracker` - основной трекер метрик

**Пример использования**:
```python
from src.utils.metrics import MetricsTracker

# Создание трекера
tracker = MetricsTracker("experiment_1")

# Добавление метрик
tracker.add_metric("reward", 15.5, timestep=100, episode=5)
tracker.add_episode_metrics(episode=5, timestep=100, reward=15.5, length=200)

# Получение статистики
summary = tracker.get_metric_summary("reward")
print(f"Средняя награда: {summary.mean}")

# Экспорт
tracker.export_to_json()
tracker.plot_metric("reward", show_moving_average=True)
```

### 5. src/experiments/base.py (T015)

**Назначение**: Базовый класс для управления экспериментами

**Ключевые возможности**:
- ✅ Абстрактный базовый класс для экспериментов
- ✅ Общие методы жизненного цикла эксперимента
- ✅ Интеграция с управлением конфигурацией
- ✅ Сбор и хранение результатов
- ✅ Обеспечение воспроизводимости
- ✅ Обработка ошибок и очистка ресурсов
- ✅ Автоматическое сохранение артефактов

**Основные классы**:
- `ExperimentManager` - абстрактный базовый класс
- `ExperimentResult` - результат эксперимента
- `SimpleExperiment` - простая реализация для прототипирования

**Пример использования**:
```python
from src.experiments.base import create_experiment
from src.utils.config import RLConfig

def my_experiment_logic(experiment):
    experiment.logger.info("Начало обучения")
    # Логика эксперимента
    experiment.metrics_tracker.add_metric("reward", 10.0)

# Создание эксперимента
config = RLConfig(experiment_name="my_experiment")
experiment = create_experiment(
    experiment_id="my_experiment",
    config=config,
    execute_func=my_experiment_logic
)

# Запуск
result = experiment.run()
print(f"Статус: {result.status}")
```

## 🔧 Интеграция модулей

Все модули спроектированы для совместной работы:

```python
from src.utils.seeding import set_seed
from src.utils.config import load_config
from src.utils.logging import setup_logging
from src.utils.metrics import MetricsTracker
from src.utils.checkpointing import CheckpointManager
from src.experiments.base import create_experiment

# Полная интеграция
def integrated_experiment():
    # 1. Воспроизводимость
    set_seed(42)
    
    # 2. Конфигурация
    config = load_config("ppo_lunarlander")
    
    # 3. Логирование
    setup_logging(log_level="INFO")
    
    # 4. Создание эксперимента с интегрированными компонентами
    def execute_func(experiment):
        # Все компоненты доступны через experiment:
        # - experiment.logger
        # - experiment.metrics_tracker
        # - experiment.seed_manager
        # - experiment.config
        pass
    
    experiment = create_experiment(
        experiment_id="integrated_experiment",
        config=config,
        execute_func=execute_func
    )
    
    return experiment.run()
```

## 📊 Особенности реализации

### Типобезопасность
- ✅ Полные type hints для Python 3.10+
- ✅ Использование dataclasses для структур данных
- ✅ Строгая типизация в интерфейсах

### Обработка ошибок
- ✅ Специфичные исключения с понятными сообщениями
- ✅ Graceful degradation при недоступности зависимостей
- ✅ Автоматическая очистка ресурсов

### Производительность
- ✅ Ленивая инициализация компонентов
- ✅ Буферизация метрик для эффективности
- ✅ Асинхронное сохранение данных где возможно

### Расширяемость
- ✅ Абстрактные базовые классы для кастомизации
- ✅ Система callbacks и hooks
- ✅ Поддержка пользовательских метрик и агрегаторов

## 🧪 Тестирование

Созданы unit тесты для проверки основной функциональности:

```bash
# Запуск тестов
pytest tests/unit/test_seeding.py -v

# Демонстрация работы
python examples/basic_usage.py
```

## 📝 Соответствие требованиям

Все модули полностью соответствуют требованиям из plan.md:

- ✅ **Python 3.10+** с полными type hints
- ✅ **Stable-Baselines3** интеграция
- ✅ **Hydra** для управления конфигурацией  
- ✅ **Воспроизводимость** через seeding и логирование
- ✅ **Файловое хранение** результатов
- ✅ **Google style** docstrings
- ✅ **Comprehensive error handling**
- ✅ **Testable interfaces**
- ✅ **Production-ready code**

Модули готовы к использованию в RL pipeline и поддерживают как интерактивную разработку в Jupyter, так и production использование.