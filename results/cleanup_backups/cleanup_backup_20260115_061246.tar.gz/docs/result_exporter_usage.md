# Руководство по использованию ResultExporter

## Обзор

`ResultExporter` - это комплексная система для экспорта результатов экспериментов RL агентов в различные форматы с автоматическим включением снимков зависимостей, валидацией целостности данных и архивированием.

## Основные возможности

- ✅ **Множественные форматы экспорта**: JSON, CSV, Excel, Pickle, HDF5, Parquet
- ✅ **Интеграция зависимостей**: Автоматическое включение снимков `pip freeze` и системной информации
- ✅ **Валидация целостности**: Проверка корректности экспортированных данных
- ✅ **Архивирование**: Сжатие в ZIP, TAR.GZ, TAR.BZ2 форматы
- ✅ **Инкрементальный экспорт**: Обновление существующих экспортов
- ✅ **Управление экспортами**: Список, очистка, генерация отчетов
- ✅ **Сводные отчеты**: HTML отчеты с статистикой и анализом

## Быстрый старт

### Простой экспорт эксперимента

```python
from src.experiments.result_exporter import export_experiment_results, ExportFormat

# Экспорт одного эксперимента
result = export_experiment_results(
    experiment,
    output_dir="results/exports",
    formats=[ExportFormat.JSON, ExportFormat.CSV],
    include_dependencies=True
)

print(f"Экспорт завершен: {result['export_dir']}")
```

### Экспорт нескольких экспериментов

```python
from src.experiments.result_exporter import export_multiple_experiments_results

# Экспорт нескольких экспериментов с сравнением
result = export_multiple_experiments_results(
    experiments=[exp1, exp2, exp3],
    output_dir="results/exports",
    formats=[ExportFormat.JSON, ExportFormat.EXCEL],
    include_comparison=True
)

print(f"Экспортировано {result['experiment_count']} экспериментов")
```

## Подробное использование

### Создание экспортера

```python
from src.experiments.result_exporter import ResultExporter, CompressionType

exporter = ResultExporter(
    output_dir="results/exports",
    include_dependencies=True,     # Включить снимки зависимостей
    validate_integrity=True,       # Валидировать целостность
    auto_compress=True,           # Автоматическое сжатие
    compression_type=CompressionType.ZIP
)
```

### Экспорт одного эксперимента

```python
# Экспорт в различные форматы
result = exporter.export_experiment(
    experiment,
    formats=[
        ExportFormat.JSON,
        ExportFormat.CSV,
        ExportFormat.EXCEL,
        ExportFormat.PICKLE
    ],
    export_name="my_experiment",
    include_raw_data=True,
    include_plots=True
)

# Информация об экспорте
print(f"Экспорт: {result['export_type']}")
print(f"Файлы: {result['exported_files']}")
print(f"Валидность: {result.get('validation', {}).get('valid', 'N/A')}")
```

### Экспорт нескольких экспериментов

```python
# Экспорт с сравнительным анализом
result = exporter.export_multiple_experiments(
    experiments=[exp1, exp2, exp3],
    formats=[ExportFormat.JSON, ExportFormat.CSV],
    export_name="comparison_study",
    include_comparison=True,  # Статистическое сравнение
    include_summary=True      # Сводная статистика
)

# Результаты сравнения включены в экспорт
print(f"Сравнение: {result.get('include_comparison')}")
```

### Инкрементальный экспорт

```python
# Обновление существующего экспорта
update_result = exporter.incremental_export(
    experiment,
    export_dir="results/exports/experiment_001_20240101_120000",
    update_existing=True
)

if update_result["updated"]:
    print(f"Обновлено файлов: {len(update_result['updated_files'])}")
```

### Управление экспортами

```python
# Список всех экспортов
exports = exporter.list_exports()
for export_info in exports:
    print(f"📦 {export_info['export_name']}")
    print(f"   Тип: {export_info['export_type']}")
    print(f"   Время: {export_info['timestamp']}")
    print(f"   Форматы: {export_info['formats']}")

# Очистка старых экспортов
cleanup_result = exporter.cleanup_old_exports(
    keep_count=10,  # Сохранить 10 последних
    keep_days=30    # Или за последние 30 дней
)

print(f"Удалено: {cleanup_result['deleted_count']} экспортов")
print(f"Освобождено: {cleanup_result['deleted_size_mb']:.2f} MB")
```

### Валидация и сжатие

```python
# Валидация существующего экспорта
validation = exporter.validate_export_integrity("path/to/export")
if validation["valid"]:
    print("✅ Экспорт валиден")
    print(f"Проверено файлов: {len(validation['checked_files'])}")
else:
    print("❌ Найдены ошибки:")
    for error in validation["errors"]:
        print(f"  - {error}")

# Сжатие экспорта
archive_path = exporter.compress_export(
    "path/to/export",
    compression_type=CompressionType.TAR_GZ,
    remove_original=False
)
print(f"Создан архив: {archive_path}")
```

### Генерация отчетов

```python
# Сводный отчет по нескольким экспортам
report_path = exporter.generate_summary_report(
    export_dirs=[
        "results/exports/exp1",
        "results/exports/exp2",
        "results/exports/exp3"
    ],
    include_statistics=True,
    include_trends=True
)

print(f"Отчет создан: {report_path}")
```

## Форматы экспорта

### JSON
- **Использование**: Универсальный формат для обмена данными
- **Содержимое**: Полная структура эксперимента с метаданными
- **Преимущества**: Читаемость, совместимость

### CSV
- **Использование**: Анализ данных в Excel/pandas
- **Содержимое**: Плоская структура метрик по временным шагам
- **Преимущества**: Простота анализа, совместимость

### Excel
- **Использование**: Отчеты и презентации
- **Содержимое**: Множественные листы с данными и метриками
- **Преимущества**: Профессиональный вид, формулы

### Pickle
- **Использование**: Сохранение Python объектов
- **Содержимое**: Полная сериализация объектов
- **Преимущества**: Точное восстановление объектов

### HDF5
- **Использование**: Большие объемы численных данных
- **Содержимое**: Иерархическая структура данных
- **Преимущества**: Эффективность, сжатие

### Parquet
- **Использование**: Аналитика больших данных
- **Содержимое**: Колоночный формат данных
- **Преимущества**: Сжатие, быстрые запросы

## Структура экспорта

```
export_directory/
├── export_metadata.json          # Метаданные экспорта
├── validation_result.json        # Результат валидации
├── experiment_data.json          # Основные данные (JSON)
├── experiment_data.csv           # Данные в CSV
├── experiment_data.xlsx          # Excel файл
├── dependencies_snapshot.json    # Снимок зависимостей
└── plots/                        # Графики (если включены)
    ├── learning_curves.png
    └── performance_comparison.png
```

## Интеграция зависимостей

Автоматически включается информация о:

- **Pip пакеты**: Вывод `pip freeze`
- **Conda пакеты**: Список conda пакетов
- **Системная информация**: ОС, Python, железо
- **ML библиотеки**: Версии ключевых библиотек
- **Git информация**: Коммит, ветка (если доступно)

## Валидация целостности

Проверяется:

- ✅ Наличие обязательных файлов
- ✅ Корректность JSON структуры
- ✅ Целостность CSV данных
- ✅ Соответствие метаданных
- ✅ Контрольные суммы файлов

## Обработка ошибок

```python
from src.experiments.result_exporter import ExportError, ValidationError

try:
    result = exporter.export_experiment(experiment)
except ExportError as e:
    print(f"Ошибка экспорта: {e}")
except ValidationError as e:
    print(f"Ошибка валидации: {e}")
except Exception as e:
    print(f"Неожиданная ошибка: {e}")
```

## Лучшие практики

### 1. Выбор форматов
- **JSON** - для универсального использования
- **CSV** - для анализа в pandas/Excel
- **Excel** - для отчетов и презентаций
- **Pickle** - для точного восстановления объектов

### 2. Управление размером
- Используйте сжатие для больших экспортов
- Регулярно очищайте старые экспорты
- Отключайте зависимости для быстрых экспортов

### 3. Организация
- Используйте осмысленные имена экспортов
- Группируйте связанные эксперименты
- Ведите документацию экспериментов

### 4. Валидация
- Всегда включайте валидацию для важных экспортов
- Проверяйте целостность перед архивированием
- Сохраняйте контрольные суммы

## Примеры использования

### Исследовательский workflow

```python
# 1. Экспорт результатов эксперимента
export_result = export_experiment_results(
    experiment,
    formats=[ExportFormat.JSON, ExportFormat.CSV],
    include_dependencies=True
)

# 2. Сравнение с базовой линией
comparison_result = export_multiple_experiments_results(
    [baseline_exp, new_exp],
    include_comparison=True
)

# 3. Архивирование для долгосрочного хранения
exporter = ResultExporter(auto_compress=True)
archived = exporter.compress_export(
    export_result['export_dir'],
    compression_type=CompressionType.TAR_GZ
)
```

### Производственный pipeline

```python
# Настройка экспортера для production
exporter = ResultExporter(
    output_dir="/data/ml_experiments",
    include_dependencies=True,
    validate_integrity=True,
    auto_compress=True
)

# Экспорт с полной валидацией
result = exporter.export_experiment(
    experiment,
    formats=[ExportFormat.JSON, ExportFormat.PARQUET],
    include_raw_data=True
)

# Автоматическая очистка
exporter.cleanup_old_exports(keep_days=90)

# Генерация отчета
report = exporter.generate_summary_report(
    [result['export_dir']],
    include_statistics=True
)
```

## Заключение

`ResultExporter` предоставляет мощную и гибкую систему для экспорта результатов RL экспериментов. Используйте его для:

- 📊 **Анализа данных** - экспорт в удобные форматы
- 🔄 **Воспроизводимости** - снимки зависимостей
- 📈 **Отчетности** - профессиональные отчеты
- 💾 **Архивирования** - долгосрочное хранение
- 🔍 **Валидации** - контроль качества данных

Для получения дополнительной информации см. исходный код и тесты в `src/experiments/result_exporter.py` и `tests/unit/experiments/test_result_exporter.py`.