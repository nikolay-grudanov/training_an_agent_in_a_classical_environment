# SAC Agent - Руководство по использованию

## Обзор

SAC (Soft Actor-Critic) агент предназначен для обучения в **непрерывных пространствах действий**. Это современный алгоритм off-policy, который использует максимизацию энтропии для улучшения исследования среды.

## Ключевые особенности

### ✅ Поддерживаемые среды
- **Только непрерывные пространства действий** (Box)
- LunarLander-v3 (непрерывная версия)
- Pendulum-v1
- BipedalWalker-v3
- MountainCarContinuous-v0

### ❌ Неподдерживаемые среды
- Дискретные пространства действий (Discrete)
- Используйте PPO, A2C или DQN для дискретных сред

### 🔧 Основные возможности
- **Автоматическая настройка энтропии** (`ent_coef="auto"`)
- **Адаптивное расписание learning rate**
- **Опциональная нормализация наблюдений**
- **Шум для исследования** (Normal, Ornstein-Uhlenbeck)
- **Ранняя остановка обучения**
- **Детальный мониторинг и логирование**
- **Автоматическое сохранение чекпоинтов**

## Быстрый старт

### 1. Базовое использование

```python
from src.agents import SACAgent, SACConfig

# Создание конфигурации
config = SACConfig(
    env_name="Pendulum-v1",
    total_timesteps=50_000,
    learning_rate=3e-4,
    buffer_size=200_000,
    batch_size=256,
)

# Создание и обучение агента
agent = SACAgent(config=config)
result = agent.train()

# Оценка производительности
metrics = agent.evaluate(n_episodes=10)
print(f"Средняя награда: {metrics['mean_reward']:.2f}")
```

### 2. Использование с конфигурационным файлом

```python
from src.utils import load_config
from src.agents import SACAgent, SACConfig

# Загрузка конфигурации из YAML
config_dict = load_config("configs/sac_config.yaml")
config = SACConfig(**config_dict)

# Создание агента
agent = SACAgent(config=config)
```

### 3. Сохранение и загрузка модели

```python
# Сохранение
agent.save("./models/my_sac_model.zip")

# Загрузка
loaded_agent = SACAgent.load("./models/my_sac_model.zip")
```

## Конфигурация

### Основные параметры

```python
config = SACConfig(
    # Базовые параметры
    env_name="LunarLander-v3",
    total_timesteps=100_000,
    seed=42,
    
    # SAC-специфичные параметры
    learning_rate=3e-4,
    buffer_size=1_000_000,
    learning_starts=10_000,
    batch_size=256,
    tau=0.005,  # Коэффициент мягкого обновления
    gamma=0.99,
    
    # Настройка энтропии
    ent_coef="auto",  # Автоматическая настройка
    target_entropy="auto",
    
    # Архитектура сети
    net_arch=[256, 256],
    activation_fn="relu",
)
```

### Оптимизированные конфигурации для разных сред

#### LunarLander-v3
```python
config = SACConfig(
    env_name="LunarLander-v3",
    learning_rate=3e-4,
    buffer_size=1_000_000,
    batch_size=256,
    tau=0.005,
    target_reward=200.0,
)
```

#### Pendulum-v1
```python
config = SACConfig(
    env_name="Pendulum-v1",
    learning_rate=1e-3,
    buffer_size=200_000,
    batch_size=256,
    tau=0.02,
    target_reward=-200.0,
    action_noise_type="normal",
    action_noise_std=0.1,
)
```

#### BipedalWalker-v3
```python
config = SACConfig(
    env_name="BipedalWalker-v3",
    total_timesteps=1_000_000,
    learning_rate=3e-4,
    buffer_size=1_000_000,
    net_arch=[400, 300],
    target_reward=300.0,
)
```

## Продвинутые возможности

### 1. Кастомные колбэки

```python
from stable_baselines3.common.callbacks import BaseCallback

class CustomCallback(BaseCallback):
    def _on_step(self) -> bool:
        # Ваша логика
        return True

agent = SACAgent(config=config)
result = agent.train(callback=CustomCallback())
```

### 2. Настройка шума для исследования

```python
config = SACConfig(
    env_name="Pendulum-v1",
    action_noise_type="normal",  # "normal" или "ornstein_uhlenbeck"
    action_noise_std=0.1,
)
```

### 3. Расписание learning rate

```python
config = SACConfig(
    env_name="LunarLander-v3",
    use_lr_schedule=True,
    lr_schedule_type="linear",  # "linear", "exponential"
    lr_final_ratio=0.1,
)
```

### 4. Ранняя остановка

```python
config = SACConfig(
    env_name="LunarLander-v3",
    early_stopping=True,
    target_reward=200.0,
    patience_episodes=100,
    min_improvement=5.0,
)
```

## Мониторинг и логирование

### TensorBoard

```python
config = SACConfig(
    env_name="LunarLander-v3",
    use_tensorboard=True,
    tensorboard_log="./logs/sac_experiment",
)

# Запуск TensorBoard
# tensorboard --logdir ./logs/sac_experiment
```

### Метрики обучения

SAC агент автоматически отслеживает:
- Награды эпизодов
- Длины эпизодов  
- Actor loss
- Critic loss
- Коэффициент энтропии
- Learning rate

### Получение информации о модели

```python
info = agent.get_model_info()
print(f"Алгоритм: {info['algorithm']}")
print(f"Размер буфера: {info['buffer_size']}")
print(f"Финальная награда: {info['final_mean_reward']}")
```

## Сравнение с PPO

| Характеристика | SAC | PPO |
|----------------|-----|-----|
| Тип алгоритма | Off-policy | On-policy |
| Пространство действий | Только непрерывные | Дискретные и непрерывные |
| Эффективность выборки | Высокая | Средняя |
| Стабильность | Высокая | Очень высокая |
| Исследование | Автоматическое (энтропия) | Требует настройки |
| Память | Требует replay buffer | Не требует |

## Рекомендации по использованию

### Когда использовать SAC:
- ✅ Непрерывные пространства действий
- ✅ Сложные задачи управления
- ✅ Когда важна эффективность выборки
- ✅ Задачи, требующие хорошего исследования

### Когда использовать PPO:
- ✅ Дискретные пространства действий
- ✅ Простые задачи
- ✅ Ограниченная память
- ✅ Нужна максимальная стабильность

## Устранение проблем

### Частые ошибки

1. **Дискретное пространство действий**
   ```
   ValueError: Алгоритм SAC не поддерживает дискретные действия
   ```
   **Решение:** Используйте PPO, A2C или DQN

2. **Медленная сходимость**
   - Увеличьте `learning_starts`
   - Настройте `ent_coef` вручную
   - Добавьте шум для исследования

3. **Нестабильное обучение**
   - Уменьшите `learning_rate`
   - Увеличьте `batch_size`
   - Включите нормализацию среды

### Отладка

```python
# Включение детального логирования
config = SACConfig(
    env_name="Pendulum-v1",
    verbose=2,  # Максимальная детализация
)

# Проверка совместимости среды
try:
    agent = SACAgent(config=config)
except ValueError as e:
    print(f"Ошибка конфигурации: {e}")
```

## Примеры

Полные примеры использования доступны в:
- `examples/sac_agent_usage.py` - Базовое использование
- `configs/sac_config.yaml` - Конфигурационные файлы
- `tests/unit/test_sac_agent.py` - Тесты и примеры

## Производительность

Типичные результаты для различных сред:

| Среда | Целевая награда | Время обучения | Шаги |
|-------|----------------|----------------|------|
| Pendulum-v1 | -200 | ~5 мин | 50K |
| LunarLander-v3 | 200 | ~15 мин | 100K |
| BipedalWalker-v3 | 300 | ~2 часа | 1M |

*Время указано для CPU Intel i7, может варьироваться в зависимости от железа.*