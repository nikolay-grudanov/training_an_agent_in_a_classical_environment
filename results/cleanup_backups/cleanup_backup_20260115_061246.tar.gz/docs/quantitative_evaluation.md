# Модуль количественной оценки RL агентов

## Обзор

Модуль `src.evaluation.quantitative_eval` предоставляет расширенные возможности для количественной оценки и статистического анализа RL агентов. Он дополняет базовый модуль `evaluator.py` дополнительными метриками, статистическими тестами и инструментами визуализации.

## Основные возможности

### 🎯 Количественная оценка
- Стандартизированная оценка на 10-20 эпизодах
- Расширенные статистические метрики (квартили, асимметрия, эксцесс)
- Показатели стабильности и консистентности
- Анализ выбросов и трендов

### 📊 Статистический анализ
- Доверительные интервалы и тесты значимости
- Сравнение с базовыми показателями (baseline)
- Размер эффекта (Cohen's d) и практическая значимость
- Непараметрические тесты (Wilcoxon)

### 🔄 Пакетная оценка
- Одновременная оценка нескольких агентов
- Попарное сравнение с статистическими тестами
- Автоматическое ранжирование по производительности
- Сводная статистика по всем агентам

### 📈 Визуализация
- Гистограммы и box plots распределений
- Временные ряды динамики обучения
- Scatter plots стабильности vs производительности
- Сравнительные барные диаграммы

### 📄 Отчеты
- Текстовые отчеты с детальной статистикой
- JSON формат для программной обработки
- CSV для анализа в Excel/pandas
- Автоматическое сохранение в файлы

## Быстрый старт

### Стандартная оценка агента

```python
from src.evaluation.quantitative_eval import evaluate_agent_standard
import gymnasium as gym

# Создание среды и агента
env = gym.make("CartPole-v1")
agent = your_trained_agent  # Ваш обученный агент

# Количественная оценка
metrics = evaluate_agent_standard(
    agent=agent,
    env=env,
    num_episodes=20,
    agent_name="PPO Agent"
)

print(f"Средняя награда: {metrics.base_metrics.mean_reward:.2f}")
print(f"Стабильность: {metrics.reward_stability_score:.3f}")
print(f"Успешность: {metrics.base_metrics.success_rate:.1%}")
```

### Сравнение агентов

```python
from src.evaluation.quantitative_eval import compare_agents_statistical

agents = {
    "PPO": ppo_agent,
    "A2C": a2c_agent,
    "SAC": sac_agent
}

# Пакетная оценка и сравнение
result = compare_agents_statistical(
    agents=agents,
    env=env,
    num_episodes=20,
    save_report=Path("comparison_report.txt"),
    save_plots=Path("comparison_plots.png")
)

print(f"Лучший агент: {result.best_agent}")
for name, score in result.ranking:
    print(f"{name}: {score:.2f}")
```

### Анализ стабильности

```python
from src.evaluation.quantitative_eval import analyze_agent_stability

# Анализ стабильности через несколько запусков
stability = analyze_agent_stability(
    agent=your_agent,
    env=env,
    num_runs=5,
    episodes_per_run=20
)

inter_run = stability["inter_run_stability"]
print(f"Коэффициент вариации: {inter_run['cv_across_runs']:.3f}")
print(f"Консистентность: {inter_run['stability_consistency']:.3f}")
```

## Основные классы

### QuantitativeEvaluator

Главный класс для количественной оценки агентов.

```python
from src.evaluation.quantitative_eval import QuantitativeEvaluator

evaluator = QuantitativeEvaluator(
    env=env,
    baseline_threshold=100.0,  # Порог для базовой линии
    success_threshold=90.0,    # Порог успешности эпизода
    min_effect_size=0.5,       # Минимальный размер эффекта
    confidence_level=0.95,     # Уровень доверия
    random_seed=42
)

# Оценка агента
metrics = evaluator.evaluate_agent_quantitative(
    agent=agent,
    num_episodes=20,
    agent_name="Test Agent"
)

# Сравнение с базовой линией
comparison = evaluator.compare_with_baseline(
    agent=agent,
    baseline_agent=baseline_agent,
    agent_name="Test Agent",
    baseline_name="Baseline"
)

# Генерация отчета
report = evaluator.generate_comprehensive_report(
    metrics=metrics,
    format_type="text"  # "text", "json", "csv"
)
```

### Структуры данных

#### QuantitativeMetrics

Расширенные метрики оценки агента:

```python
@dataclass
class QuantitativeMetrics:
    base_metrics: EvaluationMetrics  # Базовые метрики из evaluator.py
    
    # Статистические показатели
    reward_median: float
    reward_q25: float      # 25-й квартиль
    reward_q75: float      # 75-й квартиль
    reward_iqr: float      # Межквартильный размах
    reward_skewness: float # Асимметрия
    reward_kurtosis: float # Эксцесс
    
    # Показатели стабильности
    reward_cv: float                    # Коэффициент вариации
    reward_stability_score: float       # Оценка стабильности (0-1)
    consecutive_success_rate: float     # Доля последовательных успехов
    
    # Дополнительные метрики
    reward_trend_slope: float           # Тренд изменения награды
    learning_efficiency: float          # Эффективность обучения
    outlier_count: int                  # Количество выбросов
```

#### BaselineComparison

Результат сравнения с базовой линией:

```python
@dataclass
class BaselineComparison:
    agent_name: str
    baseline_name: str
    
    # Метрики
    agent_metrics: QuantitativeMetrics
    baseline_metrics: QuantitativeMetrics
    
    # Статистические тесты
    reward_improvement: float        # Процентное улучшение
    reward_ttest_pvalue: float      # p-value t-теста
    reward_wilcoxon_pvalue: float   # p-value теста Вилкоксона
    reward_significant: bool        # Статистическая значимость
    
    # Практическая значимость
    effect_size: float              # Cohen's d
    practical_significance: bool    # Превышает ли минимальный порог
    
    is_better: bool                 # Лучше ли агент базовой линии
```

## Интерпретация метрик

### Показатели стабильности

- **reward_stability_score** (0-1): Чем ближе к 1, тем стабильнее агент
- **reward_cv**: Коэффициент вариации. < 0.1 - очень стабильно, > 0.3 - нестабильно
- **consecutive_success_rate**: Доля последовательных успешных эпизодов

### Размер эффекта (Cohen's d)

- **0.2**: Малый эффект
- **0.5**: Средний эффект  
- **0.8**: Большой эффект

### Статистическая значимость

- **p-value < 0.05**: Статистически значимое различие
- **Практическая значимость**: Размер эффекта превышает минимальный порог

## Рекомендации по использованию

### Количество эпизодов

- **10-15 эпизодов**: Быстрая оценка для отладки
- **20-30 эпизодов**: Стандартная оценка для сравнения
- **50+ эпизодов**: Детальный анализ для финальной оценки

### Анализ стабильности

- **3-5 запусков**: Базовый анализ стабильности
- **10+ запусков**: Детальный анализ для критически важных применений

### Сравнение агентов

- Используйте одинаковое количество эпизодов для всех агентов
- Фиксируйте random_seed для воспроизводимости
- Обращайте внимание на практическую значимость, а не только на статистическую

## Примеры использования

Полный пример использования доступен в файле `examples/quantitative_evaluation_example.py`.

## Интеграция с существующей архитектурой

Модуль полностью интегрирован с существующей архитектурой проекта:

- Использует `src.evaluation.evaluator` для базовой функциональности
- Совместим с `src.agents.base.Agent` для работы с агентами
- Интегрирован с `src.utils.logging` для логирования
- Использует `src.utils.seeding` для воспроизводимости

## Зависимости

- `scipy.stats`: Статистические тесты и анализ
- `matplotlib`: Визуализация результатов
- `pandas`: Обработка данных и экспорт в CSV
- `numpy`: Численные вычисления

## Ограничения

- Требует обученных агентов с методом `predict()`
- Визуализация работает только с matplotlib backend
- Статистические тесты предполагают нормальное распределение (используйте непараметрические тесты при необходимости)

## Расширение функциональности

Модуль легко расширяется:

1. Добавьте новые метрики в `QuantitativeMetrics`
2. Реализуйте дополнительные статистические тесты
3. Создайте новые типы визуализации
4. Добавьте поддержку новых форматов отчетов