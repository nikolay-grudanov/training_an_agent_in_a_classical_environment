# Система отслеживания зависимостей (DependencyTracker)

## Обзор

`DependencyTracker` - это система для обеспечения воспроизводимости RL экспериментов через отслеживание зависимостей проекта, создание снимков среды и валидацию совместимости.

## Основные возможности

### 🔍 Мониторинг системы
- Информация о Python версии и реализации
- Данные об операционной системе и архитектуре
- Характеристики аппаратного обеспечения (CPU, память, GPU)
- Детектирование доступных менеджеров пакетов (pip, conda, poetry)

### 📸 Снимки зависимостей
- Создание полных снимков состояния среды
- Сохранение версий всех установленных пакетов
- Отслеживание ключевых ML библиотек
- Хеширование для детектирования изменений

### 🔄 Сравнение и валидация
- Сравнение снимков между разными состояниями
- Детектирование добавленных/удаленных/обновленных пакетов
- Валидация воспроизводимости среды
- Проверка конфликтов зависимостей

### 📤 Экспорт в различные форматы
- `requirements.txt` для pip
- `environment.yml` для conda
- `pyproject.toml` для poetry
- JSON/YAML для программного использования

## Быстрый старт

```python
from src.utils.dependency_tracker import DependencyTracker

# Инициализация трекера
tracker = DependencyTracker()

# Создание снимка зависимостей
snapshot = tracker.create_dependency_snapshot("my_experiment")

# Получение информации о системе
system_info = tracker.get_system_info()
print(f"Python: {system_info['python']['version']}")
print(f"Платформа: {system_info['platform']['system']}")

# Экспорт зависимостей
tracker.export_requirements('pip', 'requirements.txt')
```

## Интеграция с экспериментами

### Создание снимка для эксперимента
```python
from src.utils.dependency_tracker import create_experiment_snapshot

# Автоматическое создание снимка с ID эксперимента
snapshot = create_experiment_snapshot("experiment_001")
```

### Валидация среды перед запуском
```python
from src.utils.dependency_tracker import validate_environment_for_experiment

# Проверка совместимости с эталонным снимком
is_valid = validate_environment_for_experiment("reference_snapshot")
if not is_valid:
    print("⚠️ Среда не соответствует эталонной!")
```

## Основные методы

### DependencyTracker

#### Информация о системе
- `get_system_info()` - полная информация о системе
- `get_package_manager_info()` - доступные менеджеры пакетов
- `get_pip_packages()` - список pip пакетов
- `get_conda_packages()` - список conda пакетов
- `get_ml_library_versions()` - версии ML библиотек

#### Управление снимками
- `create_dependency_snapshot(name)` - создать снимок
- `load_snapshot(name)` - загрузить снимок
- `compare_snapshots(name1, name2)` - сравнить снимки
- `get_snapshots_list()` - список всех снимков
- `cleanup_old_snapshots(keep_count)` - очистка старых снимков

#### Анализ и валидация
- `detect_dependency_conflicts()` - поиск конфликтов
- `generate_compatibility_report()` - отчет совместимости
- `validate_reproducibility(reference)` - валидация воспроизводимости

#### Экспорт
- `export_requirements(format, file)` - экспорт в различные форматы

## Структура снимка

```json
{
  "metadata": {
    "name": "snapshot_name",
    "timestamp": "2023-01-01T00:00:00",
    "hash": "sha256_hash",
    "experiment_id": "optional_experiment_id"
  },
  "system": {
    "python": {"version": "3.9.0", ...},
    "platform": {"system": "Linux", ...},
    "hardware": {"cpu_count": 8, "memory_total": 16GB, ...},
    "gpu": {"cuda_available": true, ...}
  },
  "package_managers": {
    "pip": {"available": true, "version": "21.0.1"},
    "conda": {"available": true, "active_env": "myenv"}
  },
  "packages": {
    "pip": {"numpy": "1.21.0", "torch": "1.9.0", ...},
    "conda": {"numpy": "1.21.0", ...}
  },
  "ml_libraries": {
    "torch": "1.9.0",
    "stable-baselines3": "1.5.0",
    "gymnasium": "0.26.0",
    ...
  }
}
```

## Отслеживаемые ML библиотеки

- **Deep Learning**: torch, torchvision, torchaudio
- **RL**: stable-baselines3, sb3-contrib, gymnasium, gym
- **Научные**: numpy, scipy, pandas, scikit-learn
- **Визуализация**: matplotlib, seaborn, plotly
- **Логирование**: tensorboard, wandb
- **Разработка**: jupyter, ipython

## Детектирование конфликтов

Система автоматически обнаруживает:
- Конфликты зависимостей pip (`pip check`)
- Несовместимые версии библиотек (gym vs gymnasium)
- Несоответствие версий CUDA и PyTorch
- Недостаточные системные ресурсы

## Рекомендации по использованию

### 1. Создание снимков
- Создавайте снимок перед началом каждого эксперимента
- Используйте описательные имена: `baseline_ppo_lunar_v1`
- Регулярно очищайте старые снимки

### 2. Валидация среды
- Всегда валидируйте среду перед воспроизведением результатов
- Сохраняйте эталонные снимки для важных экспериментов
- Документируйте известные различия между средами

### 3. Экспорт зависимостей
- Экспортируйте requirements.txt для каждого проекта
- Используйте conda environment.yml для полного воспроизведения
- Версионируйте файлы зависимостей вместе с кодом

### 4. Мониторинг изменений
- Регулярно сравнивайте снимки для отслеживания дрейфа среды
- Автоматизируйте создание снимков в CI/CD пайплайнах
- Логируйте изменения зависимостей в экспериментах

## Примеры использования

### Полный цикл эксперимента
```python
from src.utils.dependency_tracker import DependencyTracker, create_experiment_snapshot

# 1. Создание снимка перед экспериментом
experiment_id = "ppo_lunar_baseline_v1"
snapshot = create_experiment_snapshot(experiment_id)

# 2. Запуск эксперимента
# ... код обучения агента ...

# 3. Сохранение результатов вместе со снимком
results = {
    "experiment_id": experiment_id,
    "dependency_snapshot": snapshot['metadata']['name'],
    "final_reward": 250.5,
    # ... другие метрики
}
```

### Сравнение сред разработки и продакшена
```python
tracker = DependencyTracker()

# Создание снимков в разных средах
dev_snapshot = tracker.create_dependency_snapshot("dev_environment")
prod_snapshot = tracker.create_dependency_snapshot("prod_environment")

# Сравнение различий
comparison = tracker.compare_snapshots("dev_environment", "prod_environment")
if comparison['changes']['packages_updated']:
    print("⚠️ Обнаружены различия в версиях пакетов!")
```

### Автоматическая валидация в CI
```python
import sys
from src.utils.dependency_tracker import validate_environment_for_experiment

# Проверка среды перед запуском тестов
if not validate_environment_for_experiment("reference_test_env"):
    print("❌ Среда не соответствует эталонной!")
    sys.exit(1)

print("✅ Среда валидна, запуск тестов...")
```

## Интеграция с логированием

Система автоматически интегрируется с модулем логирования проекта:

```python
from src.utils.logging import setup_logging
from src.utils.dependency_tracker import DependencyTracker

# Настройка логирования
logger = setup_logging(experiment_id="my_experiment")

# Трекер автоматически использует настроенный логгер
tracker = DependencyTracker()
snapshot = tracker.create_dependency_snapshot("my_experiment")
# Логи автоматически записываются в файлы эксперимента
```

## Файловая структура

```
results/
└── dependencies/
    ├── snapshot_experiment_001_20230101_120000.json
    ├── snapshot_baseline_ppo_20230102_140000.json
    └── snapshot_comparison_test_20230103_160000.json
```

## Производительность

- Создание снимка: ~2-5 секунд
- Сравнение снимков: ~0.1-0.5 секунд
- Валидация среды: ~1-3 секунды
- Размер снимка: ~50-200 KB (JSON)

## Ограничения

- Не отслеживает системные библиотеки (libcuda, etc.)
- Требует доступ к интернету для некоторых проверок
- Не детектирует изменения в исходном коде библиотек
- Ограниченная поддержка виртуальных сред poetry

## Устранение неполадок

### Ошибка "pip check failed"
```bash
# Проверка конфликтов вручную
pip check

# Обновление проблемных пакетов
pip install --upgrade package_name
```

### Снимок не создается
- Проверьте права доступа к директории `results/`
- Убедитесь в наличии свободного места на диске
- Проверьте доступность менеджеров пакетов

### Валидация не проходит
- Сравните версии Python между средами
- Проверьте различия в ключевых ML библиотеках
- Убедитесь в совместимости операционных систем

## См. также

- [Логирование](logging.md) - интеграция с системой логирования
- [Конфигурация](configuration.md) - управление настройками проекта
- [Эксперименты](experiments.md) - организация и запуск экспериментов