#!/usr/bin/env python3
"""
Пример использования модуля количественной оценки RL агентов.

Демонстрирует основные возможности:
- Стандартная количественная оценка агента
- Сравнение с базовой линией
- Пакетная оценка нескольких агентов
- Анализ стабильности
- Генерация отчетов и визуализация
"""

import tempfile
from pathlib import Path

import gymnasium as gym
import numpy as np



class DummyAgent:
    """Простой агент для демонстрации."""

    def __init__(self, mean_reward: float = 100.0, std_reward: float = 10.0):
        """
        Инициализация агента.

        Args:
            mean_reward: Средняя награда агента
            std_reward: Стандартное отклонение награды
        """
        self.mean_reward = mean_reward
        self.std_reward = std_reward
        self.is_trained = True

    def predict(self, observation, deterministic=True):
        """Предсказание действия (случайное)."""
        return np.array([0]), None


def create_mock_env():
    """Создание простой среды для демонстрации."""
    env = gym.make("CartPole-v1")
    return env


def main():
    """Основная функция демонстрации."""
    print("🚀 Демонстрация количественной оценки RL агентов")
    print("=" * 60)

    # Создание среды
    env = create_mock_env()
    print(f"📊 Среда: {getattr(env.spec, 'id', 'CartPole-v1')}")

    # Создание агентов для демонстрации
    agents = {
        "Стабильный агент": DummyAgent(mean_reward=150.0, std_reward=5.0),
        "Средний агент": DummyAgent(mean_reward=100.0, std_reward=15.0),
        "Нестабильный агент": DummyAgent(mean_reward=120.0, std_reward=30.0),
    }

    print(f"🤖 Создано {len(agents)} агентов для оценки")

    # 1. Стандартная оценка одного агента
    print("\n1️⃣ Стандартная количественная оценка")
    print("-" * 40)

    # agent = agents["Средний агент"]
    
    # Мокаем оценку для демонстрации
    print("Выполняется оценка агента на 20 эпизодах...")
    
    # В реальном использовании:
    # metrics = evaluate_agent_standard(
    #     agent=agent,
    #     env=env,
    #     num_episodes=20,
    #     agent_name="Средний агент"
    # )
    # print(f"✅ Средняя награда: {metrics.base_metrics.mean_reward:.2f}")
    # print(f"📈 Стабильность: {metrics.reward_stability_score:.3f}")
    # print(f"🎯 Успешность: {metrics.base_metrics.success_rate:.1%}")

    print("✅ Средняя награда: 98.50")
    print("📈 Стабильность: 0.850")
    print("🎯 Успешность: 75.0%")

    # 2. Сравнение с базовой линией
    print("\n2️⃣ Сравнение с базовой линией")
    print("-" * 40)

    # evaluator = QuantitativeEvaluator(
    #     env=env,
    #     baseline_threshold=80.0,
    #     success_threshold=50.0,
    #     min_effect_size=0.5
    # )

    print("Сравнение агента с базовой линией...")
    
    # В реальном использовании:
    # baseline_comparison = evaluator.compare_with_baseline(
    #     agent=agents["Стабильный агент"],
    #     baseline_agent=agents["Средний агент"],
    #     agent_name="Стабильный агент",
    #     baseline_name="Базовая линия"
    # )
    # print(f"📊 Улучшение: {baseline_comparison.reward_improvement:.1f}%")
    # print(f"🔬 Размер эффекта: {baseline_comparison.effect_size:.3f}")
    # print(f"✨ Практически значимо: {baseline_comparison.practical_significance}")

    print("📊 Улучшение: +52.0%")
    print("🔬 Размер эффекта: 1.250")
    print("✨ Практически значимо: True")

    # 3. Пакетная оценка нескольких агентов
    print("\n3️⃣ Пакетная оценка агентов")
    print("-" * 40)

    print("Выполняется пакетная оценка всех агентов...")
    
    # В реальном использовании:
    # batch_result = compare_agents_statistical(
    #     agents=agents,
    #     env=env,
    #     num_episodes=15
    # )
    # print(f"🏆 Лучший агент: {batch_result.best_agent}")
    # print(f"📈 Лучший результат: {batch_result.ranking[0][1]:.2f}")
    # print("\n📋 Рейтинг агентов:")
    # for i, (name, score) in enumerate(batch_result.ranking, 1):
    #     print(f"  {i}. {name}: {score:.2f}")

    print("🏆 Лучший агент: Стабильный агент")
    print("📈 Лучший результат: 148.75")
    print("\n📋 Рейтинг агентов:")
    print("  1. Стабильный агент: 148.75")
    print("  2. Нестабильный агент: 118.20")
    print("  3. Средний агент: 98.50")

    # 4. Анализ стабильности
    print("\n4️⃣ Анализ стабильности агента")
    print("-" * 40)

    print("Анализ стабильности через 5 независимых запусков...")
    
    # В реальном использовании:
    # stability_analysis = analyze_agent_stability(
    #     agent=agents["Нестабильный агент"],
    #     env=env,
    #     num_runs=5,
    #     episodes_per_run=15,
    #     agent_name="Нестабильный агент"
    # )
    # stability = stability_analysis["inter_run_stability"]
    # print(f"📊 Средняя награда: {stability['mean_reward_across_runs']:.2f}")
    # print(f"📈 Стандартное отклонение: {stability['std_reward_across_runs']:.2f}")
    # print(f"🎯 Коэффициент вариации: {stability['cv_across_runs']:.3f}")
    # print(f"✨ Консистентность стабильности: {stability['stability_consistency']:.3f}")

    print("📊 Средняя награда: 118.20")
    print("📈 Стандартное отклонение: 8.50")
    print("🎯 Коэффициент вариации: 0.072")
    print("✨ Консистентность стабильности: 0.890")

    # 5. Генерация отчетов
    print("\n5️⃣ Генерация отчетов")
    print("-" * 40)

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Создаем примеры отчетов
        text_report_path = temp_path / "evaluation_report.txt"
        json_report_path = temp_path / "evaluation_report.json"
        csv_report_path = temp_path / "evaluation_report.csv"
        
        # В реальном использовании можно генерировать отчеты:
        # evaluator.generate_comprehensive_report(
        #     metrics=batch_result,
        #     save_path=text_report_path,
        #     format_type="text"
        # )
        
        print(f"📄 Текстовый отчет: {text_report_path.name}")
        print(f"📊 JSON отчет: {json_report_path.name}")
        print(f"📈 CSV отчет: {csv_report_path.name}")

    # 6. Визуализация (демонстрация)
    print("\n6️⃣ Визуализация результатов")
    print("-" * 40)

    print("📊 Доступные типы визуализации:")
    print("  • Гистограммы распределения наград")
    print("  • Box plots для сравнения агентов")
    print("  • Временные ряды динамики обучения")
    print("  • Scatter plots стабильности vs производительности")
    print("  • Барные диаграммы средних значений")

    # В реальном использовании:
    # evaluator.visualize_results(
    #     metrics=batch_result.agents_metrics,
    #     save_path=temp_path / "comparison_plots.png",
    #     show_plots=False
    # )

    print("\n✅ Демонстрация завершена!")
    print("\n💡 Для реального использования:")
    print("   1. Замените DummyAgent на ваших обученных агентов")
    print("   2. Раскомментируйте строки с реальными вызовами функций")
    print("   3. Настройте параметры оценки под вашу задачу")
    print("   4. Используйте результаты для анализа и улучшения агентов")

    env.close()


if __name__ == "__main__":
    main()