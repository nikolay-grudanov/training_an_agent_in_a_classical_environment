# TrainingLoop - Детальная реализация тренировочного цикла

## 📋 Обзор

Модуль `src/training/train_loop.py` предоставляет детальную реализацию тренировочного цикла для RL агентов с поддержкой различных стратегий обучения, мониторинга прогресса в реальном времени и интеграции с системами логирования.

## 🏗️ Архитектура

### Основные компоненты

1. **TrainingLoop** - Главный класс тренировочного цикла
2. **TrainingProgress** - Отслеживание прогресса обучения
3. **TrainingStatistics** - Детальная статистика обучения
4. **ProgressReporter** - Репортер прогресса с TensorBoard
5. **Хуки обучения** - Пользовательские callbacks

### Стратегии обучения

- **EPISODIC** - Обучение по эпизодам
- **TIMESTEP_BASED** - Обучение по временным шагам
- **MIXED** - Смешанная стратегия
- **ADAPTIVE** - Адаптивная стратегия

## 📊 Статистика реализации

- **Строк кода**: 1,267
- **Классов и функций**: 74
- **Основные классы**: 8
- **Перечисления**: 2
- **Хуки**: 2 предопределенных

## 🚀 Основные возможности

### 1. Мониторинг прогресса
```python
progress = TrainingProgress()
progress.update_performance_stats(current_time)
progress.update_resource_usage()
```

### 2. Различные стратегии обучения
```python
training_loop = TrainingLoop(
    agent=agent,
    env=env,
    strategy=TrainingStrategy.ADAPTIVE,
    total_timesteps=100_000
)
```

### 3. Пользовательские хуки
```python
class CustomHook:
    def on_training_start(self, progress): pass
    def on_step(self, progress, step_info): pass
    def on_episode_end(self, progress, episode_info): pass

training_loop.add_hook(CustomHook())
```

### 4. Graceful shutdown
```python
# Обработка SIGINT/SIGTERM
training_loop.stop()  # Программная остановка
training_loop.pause() # Приостановка
training_loop.resume() # Возобновление
```

### 5. Мониторинг ресурсов
```python
# Автоматический мониторинг памяти, CPU, GPU
training_loop = TrainingLoop(
    memory_limit_mb=500.0,
    convergence_threshold=200.0
)
```

## 📈 Интеграции

### TensorBoard
```python
reporter = ProgressReporter(
    tensorboard_log_dir="logs/tensorboard"
)
```

### Метрики
- Интеграция с `MetricsTracker`
- Экспорт в JSON/CSV
- Построение графиков

### Чекпоинты
- Автоматическое сохранение
- Восстановление состояния
- Управление версиями

## 🔧 Конфигурация

### Создание из конфигурации
```python
config = {
    "strategy": "adaptive",
    "total_timesteps": 100_000,
    "eval_freq": 10_000,
    "checkpoint_freq": 25_000,
    "memory_limit_mb": 500.0,
    "enable_early_stopping": True,
    "tensorboard_log_dir": "logs/tb"
}

training_loop = create_training_loop(agent, env, config)
```

## 📋 Классы и их назначение

### TrainingProgress
- Отслеживание текущего состояния
- Производительность (шагов/сек, эпизодов/мин)
- Использование ресурсов (память, CPU, GPU)
- Статистика эпизодов

### TrainingStatistics
- Общая статистика обучения
- Определение сходимости
- Агрегированные метрики
- История обучения

### ProgressReporter
- Консольный вывод с прогресс-баром
- Логирование в файлы
- Интеграция с TensorBoard
- Форматирование времени

### TrainingLoop
- Основной цикл обучения
- Управление стратегиями
- Обработка прерываний
- Координация компонентов

## 🎯 Предопределенные хуки

### LoggingHook
```python
hook = LoggingHook(log_interval=1000)
training_loop.add_hook(hook)
```

### EarlyStoppingHook
```python
hook = EarlyStoppingHook(
    patience=10,
    min_improvement=0.01
)
training_loop.add_hook(hook)
```

## 🔄 Жизненный цикл обучения

1. **Инициализация** - Настройка компонентов
2. **Начало обучения** - Вызов хуков `on_training_start`
3. **Цикл обучения** - Выполнение стратегии
4. **Мониторинг** - Обновление прогресса и метрик
5. **Периодические операции** - Оценка, чекпоинты, сохранение
6. **Завершение** - Финализация и очистка

## 📝 Примеры использования

Смотрите `examples/train_loop_usage.py` для детальных примеров:

- Базовое обучение
- Эпизодическое обучение
- Ранний останов
- Адаптивное обучение
- Конфигурационное обучение
- Приостановка/возобновление
- Мониторинг ресурсов

## 🧪 Тестирование

Тесты находятся в:
- `tests/test_train_loop.py` - Полные тесты (требуют зависимости)
- `tests/test_train_loop_simple.py` - Упрощенные тесты

## 🔗 Интеграция с проектом

Модуль интегрируется с:
- `src.agents` - RL агенты
- `src.utils.metrics` - Система метрик
- `src.utils.logging` - Логирование
- `src.utils.checkpointing` - Чекпоинты
- `src.training.trainer` - Высокоуровневый тренер

## 📦 Зависимости

- `gymnasium` - Среды RL
- `stable_baselines3` - RL алгоритмы
- `torch` - PyTorch для GPU
- `psutil` - Мониторинг ресурсов
- `tensorboard` - Визуализация
- `numpy` - Численные вычисления
- `matplotlib` - Графики

## 🎉 Заключение

TrainingLoop предоставляет мощную и гибкую систему для обучения RL агентов с:

- ✅ Поддержкой различных стратегий обучения
- ✅ Детальным мониторингом прогресса
- ✅ Интеграцией с системами логирования
- ✅ Graceful shutdown и управлением ресурсами
- ✅ Расширяемостью через пользовательские хуки
- ✅ Полной интеграцией с экосистемой проекта

Модуль готов к использованию в продакшене и обеспечивает все необходимые возможности для эффективного обучения RL агентов.